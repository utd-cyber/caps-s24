
if (!require("pacman")) install.packages("pacman")
p_load(rvest) # Packages for scraping
p_load(data.table, dplyr, tidyr, stringr, plyr, ggplot2, stringi) # Packages for text mining
# p_load(stringfix)
`%+%` <- function(x,y){paste0(x,y)} # Concatenate strings
`%gic%` <- function(x,y){grepl(x, y, ignore.case = TRUE)} # Pattern in a string

p_load(shiny)

#design server


# Define server logic
# Define USER INTERFACE
ui <- fluidPage(
  titlePanel("Cybersecurity Model Deployment"),
  
  sidebarLayout(
    sidebarPanel(
      # Input: Specify input fields for new data
      numericInput("feature1", "Feature 1", value = 1),
      numericInput("feature2", "Feature 2", value = 1),
      # Add more inputs as needed based on your model
      
      actionButton("predict", "Predict")
    ),
    
    mainPanel(
      textOutput("prediction")
    )
  )
)

# Server Logic




server <- function(input, output) {
  
  # Load the saved model



 model <- readRDS("0-Data/model.rds")
  
  observeEvent(input$predict, {
    # Create a new data frame based on user input
    new_data <- data.frame(
      feature1 = input$feature1,
      feature2 = input$feature2
      # Add more features as needed
    )
    
    # Make prediction
    prediction <- predict(model, new_data)
    
    # Output prediction
    output$prediction <- renderText({
      paste("Prediction: ", prediction)
    })
  })
}


shinyApp(ui = ui, server = server)





